const express = require('express');
const router = express.Router();
const Result = require('../models/Result');

// Save result
router.post('/save-result', async (req, res) => {
  const { username, score, category } = req.body;

  try {
    const newResult = new Result({ username, score, category });
    await newResult.save();
    res.status(201).json({ message: '✅ Result saved!' });
  } catch (err) {
    res.status(500).json({ error: '❌ Could not save result.' });
  }
});

// Get top 10 leaderboard
router.get('/leaderboard', async (req, res) => {
  try {
    const results = await Result.find().sort({ score: -1, date: 1 }).limit(10);
    res.status(200).json(results);
  } catch (err) {
    res.status(500).json({ error: '❌ Failed to fetch leaderboard.' });
  }
});

module.exports = router;
